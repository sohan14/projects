from morse import Morse

word=input('Please enter word: ')
morse=Morse()
print(morse.encrypt(word))